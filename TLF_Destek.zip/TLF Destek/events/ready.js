const chalk = require('chalk');

module.exports = {
  name: 'ready',
  execute(client) {
    console.log(chalk.green('[Phoen1x]') + chalk.cyan(' Phoen1x Bot Destek'))
    console.log(chalk.red('=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+='))
    console.log(chalk.green('Name: ') + chalk.cyan('Phoen1x'))
    console.log(chalk.green('Bot Status: ') + chalk.cyan('Aktif'))
    console.log(chalk.red('=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+='))
    const oniChan = client.channels.cache.get(client.config.ticketChannel)




    function sendTicketMSG() {
      const embed = new client.discord.MessageEmbed()
        .setColor('6d6ee8')
        .setAuthor('Ticket', client.user.avatarURL())
        .setDescription('Aşağıdaki Butona Basarak Ticket Açabilirsin.Eğer gereksiz sebepte Ticket açılırsa,bu açan kişinin banlanmasıyla sonuçlanır')
        .setFooter(`${client.user.tag}  `, client.user.displayAvatarURL())
      const row = new client.discord.MessageActionRow()
        .addComponents(
          new client.discord.MessageButton()
          .setCustomId('open-ticket')
          .setLabel('Ticket Aç')
          .setEmoji('✉️')
          .setStyle('PRIMARY'),
        );
        
        

      oniChan.send({
        embeds: [embed],
        components: [row]
      })
    };

     oniChan.bulkDelete(100).then(() => {
      sendTicketMSG(),

     

  
      console.log(chalk.green('[Tickety v2]') + chalk.cyan(' Sent the ticket creation widget..'))
    })
  },
};